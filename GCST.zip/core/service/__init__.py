from core.service.__main__ import Service
from core.service.datacls import ServiceResponseModel

__all__ = [
    "Service",
    "ServiceResponseModel",
]