from core.lib.exercise.__main__ import score_message

__all__ = [
    "score_message",
]
