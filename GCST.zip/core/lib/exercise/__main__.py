score_message = "\n\nБалл за ответ: {task_score}% из {max_score}%\n\n"
