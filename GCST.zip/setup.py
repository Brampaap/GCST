import setuptools

setuptools.setup(
    name="trainer-demo",
    version="0.0.1",
    python_requires=">=3.10",
    packages=["."],
)
